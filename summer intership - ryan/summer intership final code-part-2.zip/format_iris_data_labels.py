import pandas as pd

data_original = pd.read_csv('iris.data2.txt', header = None, sep = None, skipinitialspace = True)
print(data_original.shape)
for i in range (data_original.shape[0]):
    if (data_original.iloc[i,4] == 0):
        data_original.iloc[i,4] = 'setosa'
    elif (data_original.iloc[i,4] == 1):
        data_original.iloc[i,4] = 'versicolor'
    else:
        data_original.iloc[i,4] = 'virginica'

data_original.to_csv('iris_class_labels_formatted.txt',sep = ',', index = False, header = False)