#use this to uyse pre existing classifier and clustering object on new data to make new classifier or cluster object use cmd_build_classifiers_clusters
from code_restructored_gui_functions_seperate import data_analysis_and_visulization

def pre_checks(classifier_file_location, data_set_file_location,header_state, columns_to_drop, classification_column):
    if classifier_file_location == None:
        print('please give file location')
    else:
        load_classifier(classifier_file_location, data_set_file_location,header_state,columns_to_drop, classification_column)

def load_classifier(classifier_file_location, data_set_file_location,header_state,columns_to_drop, classification_column):
    ax = data_analysis_and_visulization.loading_data.load_object(classifier_file_location)
    
    data_frame = data_analysis_and_visulization.loading_data.read_data_in(data_set_file_location,header_state)
    
    data_frame_columns_dropped = data_analysis_and_visulization.pre_processing_data.drop_columns(data_frame, columns_to_drop, classification_column, header_state) 
    
    print('predicting')
    Y_predict = None
    if ('k_means' in classifier_file_location) or ('k_modes' in classifier_file_location) or ('k_protype' in classifier_file_location):
        print('clustering')
        if ('k_means' in classifier_file_location) or ('k_modes' in classifier_file_location):
            Y_predict = ax.predict(data_frame_columns_dropped)
            plot_cluster(data_frame_columns_dropped, Y_predict, classifier_file_location, header_state)
        else:
            numerical_list, categorical_list = data_analysis_and_visulization.pre_processing_data.find_data_types(data_frame_columns_dropped)
            Y_predict = ax.fit_predict(data_frame_columns_dropped.as_matrix(), categorical = [int(x) for x in categorical_list])
            plot_cluster(data_frame_columns_dropped, Y_predict, classifier_file_location, header_state)
    else:
        print('classification')
        Y_predict = ax.predict(data_frame_columns_dropped)
        data_frame['classification_column'] = Y_predict
        view_row(data_frame)

def view_row(data_set):
    continue_var = True
    while continue_var == True:
        row_num = int(input('enter a row num to see that row (-1 to end): '))
        if row_num == -1:
            continue_var = False
        print(data_set.iloc[row_num,:])

def plot_cluster(data_frame_columns_dropped, Y_predict, file_location, header_state):
    print(Y_predict.shape)
    print(data_frame_columns_dropped.shape)
    data_set_numerical_data_converted = data_analysis_and_visulization.pre_processing_data.find_data_types_and_convert(data_frame_columns_dropped)
    data_set_numerical_data_converted_cluster_labels = data_analysis_and_visulization.clustering.attach_cluster_labels(data_set_numerical_data_converted.copy(deep=True), Y_predict)
    
    data_set_pca = data_analysis_and_visulization.displaying_data.do_pca(data_set_numerical_data_converted)
    data_set_pca_group_cluster = data_analysis_and_visulization.clustering.attach_cluster_labels(data_set_pca, Y_predict)
    
    columns_to_use = data_analysis_and_visulization.displaying_data.get_columns_to_use()
    print(columns_to_use)
    data_analysis_and_visulization.displaying_data.plotting_multiple_plots(data_set_numerical_data_converted_cluster_labels,columns_to_use, file_location, header_state, '')
    columns_to_use = [[0,1],[0,1,2]]
    data_analysis_and_visulization.displaying_data.plotting_multiple_plots(data_set_pca_group_cluster,columns_to_use, file_location, header_state, 'pca')