#by it self this will not do anything this just contains all the methords that are used in cmd_build_classifiers_clusters and load_classifiers_and_clusters.py
from mpl_toolkits.mplot3d import Axes3D

import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure

import numpy as np

import tkinter as tk
from tkinter.filedialog import askopenfilename


import pandas as pd
from pandas.tools.plotting import parallel_coordinates

from sklearn.cluster import KMeans
from sklearn import decomposition
from sklearn.manifold import TSNE
from sklearn.ensemble import RandomForestClassifier
from sklearn import tree
from sklearn import svm
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import silhouette_score

import pydotplus
import pylab

from kmodes import kmodes
from kmodes import kprototypes

import os
from os.path import normpath, basename

import imageio

import pickle

class data_analysis_and_visulization():
    class pre_processing_data():
        def drop_columns(data_original, columns_to_drop, classification_column, header_state):
            print('dropping columns')
            test_data_set = data_original.copy(deep = True)
            test_data_set = test_data_set.dropna(axis=0, how='any')
            if not (columns_to_drop == None):
                for i in range(len(columns_to_drop)):
                    temp_var = columns_to_drop[i]
                    test_data_set.drop(temp_var, axis = 1, inplace = True)        
            test_data_set.astype(float,raise_on_error=False)  
            if not (classification_column == None):
                test_data_set.drop(classification_column, axis = 1, inplace = True)
            print('finished dropping columns')
            return test_data_set
    
        def check_if_string(var):
            try:
                float(var)
                return False
            except ValueError:
                return True
        
        def find_data_types(data_set):
            print('finding data types')
            data_set_shape = data_set.shape
            numerical_list = []
            categorical_list = []
                
            for column_num in range(data_set_shape[1]):
                temp_var = data_set.iloc[0,column_num]
                if (data_analysis_and_visulization.pre_processing_data.check_if_string(temp_var) == True):
                    categorical_list.append(column_num)
                else:
                    numerical_list.append(column_num)
            print('finished finding data types')
            print('numerical list - ',numerical_list)
            print('categorical list - ',categorical_list)
            return numerical_list, categorical_list
        
        def find_data_types_and_convert(data_set):
            print('finding data types and converting')
            data_set_shape = data_set.shape
            numerical_list = []
            categorical_list = []
                
            for column_num in range(data_set_shape[1]):
                temp_var = data_set.iloc[0,column_num]
                if (data_analysis_and_visulization.pre_processing_data.check_if_string(temp_var) == True):
                    categorical_list.append(column_num)
                    data_set = data_analysis_and_visulization.pre_processing_data.convert_non_numerical_data(data_set, column_num)
                else:
                    numerical_list.append(column_num)
            print('finished finiding data types and converting')
            return data_set
        
        def convert_non_numerical_data(data_set, column_num):
            print('converting non numerical data on column ',column_num)
            data_set_shape = data_set.shape
            dictonary_var = {}
            highest_num = 0
                    
            for row_num in range(data_set_shape[0]):
                #print('row - ',row_num,' column - ',column_num)
                #print(data_set.iloc[row_num][column_num])
                #temp_var = data_set.iloc[row_num][column_num]
                temp_var = data_set.iloc[row_num,column_num]
                if data_analysis_and_visulization.pre_processing_data.check_if_string(temp_var) == True:
                    if temp_var not in dictonary_var:
                        if len(dictonary_var) == 0:
                            dictonary_var[temp_var] = 0
                            highest_num = 0
                        else:
                            dictonary_var[temp_var] = highest_num + 1
                            highest_num = highest_num + 1
                    #data_set.set_value(row_num,column_num,dictonary_var.get(temp_var))
                    data_set.iloc[row_num,column_num] = dictonary_var.get(temp_var)
            print('finished converting non numerical data on column ',column_num)
            return data_set
    
    class clustering():
        #find_k _means, find_k_kprotype, find_k_kmode are used to cluser data when k is unkown they run the clustering algarithms with different values of k then plot the results for someone
        #to use the elbow methord on to decide k
        def find_k_kmeans(data_set):
            temp_array = []
            temp_array_2 = [2,3,4,5,6,7,8,9,10]
            for i in range(2,11):
                clf = KMeans(n_clusters = i)
                clf.fit(data_set)
                temp_var = (clf.score(data_set))
                temp_array.append(temp_var)
                print(temp_var)
            fig = plt.figure()
            ax = fig.add_subplot(111)
            ax.plot(temp_array,temp_array_2)
            plt.xlabel('score from clf')
            plt.ylabel('k')
            plt.show()
            
            temp_array = []
            temp_array_2 = [2,3,4,5,6,7,8,9,10]
            for i in range(2,11):
                clf = KMeans(n_clusters = i)
                clf.fit(data_set)
                labels = clf.labels_
                sil_coeff = silhouette_score(data_set, labels, metric = 'euclidean')
                temp_array.append(sil_coeff)
                print(sil_coeff)
            fig = plt.figure()
            ax = fig.add_subplot(111)
            ax.plot(temp_array,temp_array_2)
            plt.xlabel('silhouette_score')
            plt.ylabel('k')
            plt.show()
            
        def find_k_kprotype(data_set):
            temp_array = []
            temp_array_2 = [2,3,4,5,6,7,8,9,10]
            for i in range(2,11):
                kproto = kprototypes.KPrototypes(n_clusters = num_of_clusters, init = 'Cao', verbose=2)
                clf = kproto.fit(data_set.as_matrix(), categorical = [int(x) for x in categorical_columns])
                temp_var = (clf.score(data_set))
                temp_array.append(temp_var)
                print(temp_var)
            fig = plt.figure()
            ax = fig.add_subplot(111)
            ax.plot(temp_array,temp_array_2)
            plt.xlabel('score from clf')
            plt.ylabel('k')
            plt.show()
            
            temp_array = []
            temp_array_2 = [2,3,4,5,6,7,8,9,10]
            for i in range(2,11):
                kproto = kprototypes.KPrototypes(n_clusters = num_of_clusters, init = 'Cao', verbose=2)
                labels = kproto.fit_predict(data_set.as_matrix(), categorical = [int(x) for x in categorical_columns])
                sil_coeff = silhouette_score(data_set, labels, metric = 'euclidean')
                temp_array.append(sil_coeff)
                print(sil_coeff)
            fig = plt.figure()
            ax = fig.add_subplot(111)
            ax.plot(temp_array,temp_array_2)
            plt.xlabel('silhouette_score')
            plt.ylabel('k')
            plt.show()
        
        def find_k_kmode(data_set):
            temp_array = []
            temp_array_2 = [2,3,4,5,6,7,8,9,10]
            for i in range(2,11):
                km = kmodes.KModes(n_clusters = num_of_clusters, init = 'Cao', verbose=2)
                clf = km.fit(data_set)
                temp_var = (clf.score(data_set))
                temp_array.append(temp_var)
                print(temp_var)
            fig = plt.figure()
            ax = fig.add_subplot(111)
            ax.plot(temp_array,temp_array_2)
            plt.xlabel('score from clf')
            plt.ylabel('k')
            plt.show()
            
            temp_array = []
            temp_array_2 = [2,3,4,5,6,7,8,9,10]
            for i in range(2,11):
                km = kmodes.KModes(n_clusters= num_of_clusters)
                labels = km.fit_predict(data_set)
                sil_coeff = silhouette_score(data_set, labels, metric = 'euclidean')
                temp_array.append(sil_coeff)
                print(sil_coeff)
            fig = plt.figure()
            ax = fig.add_subplot(111)
            ax.plot(temp_array,temp_array_2)
            plt.xlabel('silhouette_score')
            plt.ylabel('k')
            plt.show()
        
        
        #do_k_means, do_k_protype, do_k_modes are used when k is known and provided by the user
        def do_k_means(num_of_clusters, data_set):                
            print('making k means')
            clf = KMeans(n_clusters = num_of_clusters)
            clf.fit(data_set)
            print('finished making k means')
            return clf
            
        def do_k_protype(num_of_clusters, data_set, categorical_columns):
            printß('starting k protype')
            print(categorical_columns)
            kproto = kprototypes.KPrototypes(n_clusters = num_of_clusters, init = 'Cao', verbose=2)
            #clf = kproto.fit_predict(data_set.as_matrix(), categorical = [categorical_columns])
            clf = kproto.fit_predict(data_set.as_matrix(), categorical = [int(x) for x in categorical_columns])
            print('finished k protype')
            return clf
            
        def do_k_modes(num_of_clusters, data_set):
            print('starting k modes')
            km = kmodes.KModes(n_clusters= num_of_clusters)
            clf = km.fit_predict(data_set)
            print('finished k modes')
            return clf
        
        def attach_cluster_labels(data_set, labels):
            print('data set - ',data_set.shape, ' : clf labels var - ',labels.shape)
            data_set = pd.DataFrame(data_set)
            print('adding cluster group row into dataset')
            #data_set.loc['cluster_group'] = np.nan
            data_set['cluster_group'] = np.nan
            data_set['cluster_group'] = labels
            print('cluster group row now added')
            return data_set
    
    class classification():
        def do_decsion_tree(X_train, X_test, Y_train, Y_test):
            print('---------------------------------------------------')
            print('making decsion tree')
            clf = tree.DecisionTreeClassifier()
            clf.fit(X_train, Y_train)
            print('finished decsion tree')
            print('testing decsion tree')
            Y_pred = (clf.predict(X_test))
            print('finished testing decsion tree')
            print('accuracy is ', accuracy_score(Y_test,Y_pred) * 100)
            print('---------------------------------------------------')
            return clf, Y_pred
        
        def do_random_forest(X_train, X_test, Y_train, Y_test):
            print('---------------------------------------------------')
            print('making random forest')
            clf = RandomForestClassifier()
            clf.fit(X_train, Y_train)
            print('finished random forest')
            print('testing random forest')
            Y_pred = (clf.predict(X_test))
            print('finished testing random forest')
            print('accuracy is ', accuracy_score(Y_test,Y_pred) * 100)
            print('---------------------------------------------------')
            return clf, Y_pred
        
        def do_support_vector_machine(X_train, X_test, Y_train, Y_test):
            print('---------------------------------------------------')
            print('making support vector machine')
            clf = svm.SVC()
            clf.fit(X_train, Y_train)
            print('finished support vector machine')
            print('testing support vector machine')
            Y_pred = (clf.predict(X_test))
            print('finished support vector machine')
            print('accuracy is ', accuracy_score(Y_test,Y_pred) * 100)
            print('---------------------------------------------------')
            return clf, Y_pred
        
        def do_naive_bytes(X_train, X_test, Y_train, Y_test):
            print('---------------------------------------------------')
            print('making naive bayes')
            clf = GaussianNB()
            clf.fit(X_train, Y_train)
            print('finished making naive bayes')
            print('testing naive bayes')
            Y_pred = (clf.predict(X_test))
            print('finished naive bayes')
            print('accuracy is ', accuracy_score(Y_test,Y_pred) * 100)
            print('---------------------------------------------------')
            return clf, Y_pred
        
        def do_nerual_net(X_train, X_test, Y_train, Y_test):
            print('---------------------------------------------------')
            print('making neural network')
            clf = MLPClassifier()
            clf.fit(X_train, Y_train)
            print('finished making neural network')
            print('testing neural network')
            Y_pred = (clf.predict(X_test))
            print('finished neural network')
            print('accuracy is ', accuracy_score(Y_test,Y_pred) * 100)
            print('---------------------------------------------------')
            return clf, Y_pred
    
    class displaying_data():
        def view_row(data_set):
            continue_var = True
            while continue_var == True:
                row_num = int(input('enter a row num to see that row (-1 to end): '))
                if row_num == -1:
                    continue_var = False
                print(data_set.iloc[row_num,:])
        
        def do_tsne(data_set):    
            print('starting tsne')
            tsne = TSNE(n_components= 3)
            data_set_tsne = tsne.fit_transform(data_set)
            print('finished tsn')
            return data_set_tsne
            
        def do_pca(data_set):    
            print('starting pca')
            pca = decomposition.PCA(n_components= 3)
            pca.fit(data_set)
            data_set_pca = pca.transform(data_set)
            #data_set_pca = pca.transform(data_set)
            print('finished pca')
            print(pca.explained_variance_ratio_)
            return data_set_pca
        
        def plotting_multiple_plots(dataset,columns_to_use, file_location, header_state, name_addition):
            for i in range(len(columns_to_use)):
                temp_list = columns_to_use[i]
                if (len(temp_list)) == 2:
                    data_analysis_and_visulization.displaying_data.scatter_graph_2d_from_plotting_multiple(dataset,temp_list, file_location, header_state, name_addition)
                elif (len(temp_list)) == 3:
                    data_analysis_and_visulization.displaying_data.scatter_graph_3d_from_plotting_multiple(dataset, temp_list, file_location, header_state, name_addition)
            
        def scatter_graph_2d_from_plotting_multiple(dataset, columns_to_use, file_location, header_state, name_addition):
            num_clusters = len(dataset.loc[:,'cluster_group'].unique())
            colors = 10 * ['r','g','b','c','k','y','m']
            fig = plt.figure(figsize = (50,50))
            ax = fig.add_subplot(111)
            names = dataset.columns.values
            for i in range(num_clusters):
                temp_df = dataset[(dataset['cluster_group'] == i)]
                print('i = ', i, ' dataset size ',temp_df.shape, ' color to use is ', colors[i])
                x = temp_df.iloc[:, columns_to_use[0]]
                y = temp_df.iloc[:, columns_to_use[1]]
                ax.scatter(x, y, color=colors[i])
            plt.xlabel(names[columns_to_use[0]])
            plt.ylabel(names[columns_to_use[1]])
            plt.show()
            
            file_name = basename(normpath(file_location))
            file_name = os.path.splitext(file_name)[0]
            if header_state == False:
                file_name = name_addition + '_' + file_name + '_column' + str(names[columns_to_use[0]]) + '_column' + str(names[columns_to_use[1]]) + '_2d'
            else:
                file_name = name_addition + '_' + file_name + '_column' + str(names[columns_to_use[0]]) + '_column' + str(names[columns_to_use[1]]) + '_2d'
            data_analysis_and_visulization.saving_data.save_png_pylab(file_location, file_name, fig)
            data_analysis_and_visulization.saving_data.save_pd_dataframe(file_location, file_name, dataset)
        
        def scatter_graph_3d_from_plotting_multiple(dataset, columns_to_use, file_location, header_state, name_addition):
            num_clusters = len(dataset.loc[:,'cluster_group'].unique())
            colors = 10 * ['r','g','b','c','k','y','m']
            fig = plt.figure(figsize = (50,50))
            ax = fig.add_subplot(111, projection='3d')
            names = dataset.columns.values
            for i in range(num_clusters):
                temp_df = dataset[(dataset['cluster_group'] == i)]
                print('i = ', i, ' dataset size ',temp_df.shape, ' color to use is ', colors[i])
                x = temp_df.iloc[:, columns_to_use[0]]
                y = temp_df.iloc[:, columns_to_use[1]]
                z = temp_df.iloc[:, columns_to_use[2]]
                ax.scatter(x, y, z, color=colors[i])
            plt.xlabel(names[columns_to_use[0]])
            plt.ylabel(names[columns_to_use[1]])
            plt.show()
            
            file_name = basename(normpath(file_location))
            file_name = os.path.splitext(file_name)[0]
            if header_state == False:
                file_name = name_addition + '_' + file_name + '_column' + str(names[columns_to_use[0]]) + '_column' + str(names[columns_to_use[1]]) + '_column' + str(names[columns_to_use[2]]) + '_3d'
            else:
                file_name = name_addition + '_' + file_name + '_column' + str(names[columns_to_use[0]]) + '_column' + str(names[columns_to_use[1]]) + '_column' + str(names[columns_to_use[2]]) +'_3d'
            data_analysis_and_visulization.saving_data.save_png_pylab(file_location, file_name, fig)
            data_analysis_and_visulization.saving_data.save_pd_dataframe(file_location, file_name, dataset)
        
        def scatter_graph_3d_rotate_360_to_video(dataset,columns_to_use):
            print('starting plotting 3d and rotating')
            plt.ioff()
            num_clusters = len(np.unique(dataset['cluster_group']))
            colors = 10 * ['r','g','b','c','k','y','m']
            names = dataset.columns.values
            for k in range(360):
                print('rotation is ',k)
                fig = plt.figure(figsize = (50,50))
                ax = fig.add_subplot(111, projection='3d')
                for i in range(num_clusters):
                    temp_df = dataset[(dataset['cluster_group'] == i)]
                    x = temp_df.iloc[:, columns_to_use[0]]
                    y = temp_df.iloc[:, columns_to_use[1]]
                    z = temp_df.iloc[:, columns_to_use[2]]
                    ax.scatter(x, y, z ,color=colors[i])      
                ax.set_xlabel(names[0])
                ax.set_ylabel(names[1])
                ax.set_zlabel(names[2]) 
                ax.view_init(elev=10., azim=k)
                file_name = '2nd_test/3d_'+str(k)+'.png'
                pylab.savefig(file_name)
                plt.close(fig)
            plt.ion()
            print('finished plotting 3d and rotating')
    
        def convert_360_png_to_video():
            print('starting making video from the png files')
            images = []
            for i in range(360):
                file_name = 'test_3d_360/3d_'+str(i)+'.png'
                images.append(imageio.imread(file_name))
            imageio.mimsave('test_3d_360/test_video.gif', images)
            print('finished making video from the png files')
            
        def get_columns_to_use():
            continue_var = 'True'
            columns_to_use = []
            while continue_var == 'True':
                temp_list = []
                temp_string_var = input('enter set of columns: ')
                temp_list = temp_string_var.split(',')
                for i in range(len(temp_list)):
                    try:
                        temp_list[i] = int(temp_list[i])
                    except ValueError:
                        pass
                columns_to_use.append(temp_list)
                continue_var = input('is there more to enter (True/False) : ')
            return columns_to_use
        
        def plot_parallel_coordinates(data_original, classification_column):
            parallel_coordinates(data_original, classification_column)
            plt.draw()
    
    class saving_data():
        def check_top_folder(folder_name):
            folder_name = basename(normpath(folder_name))
            folder_name = os.path.splitext(folder_name)[0]
            if os.path.exists(folder_name) == True:
                pass
            else:
                os.makedirs(folder_name)
            print(folder_name)
            return folder_name
        
        def check_sub_folder(folder_name, type_var):
            folder_name = folder_name + '/' + type_var
            if os.path.exists(folder_name) == True:
                pass
            else:
                os.makedirs(folder_name)
            print(folder_name)
            return folder_name
        
        def check_fig_sub_folder(folder_name):
            if os.path.exists(folder_name) == True:
                pass
            else:
                os.makedirs(folder_name)
    
        def save_png_pylab(folder_name, file_name, fig):
            file_name_temp = file_name
            folder_name = data_analysis_and_visulization.saving_data.check_top_folder(folder_name)
            folder_name = data_analysis_and_visulization.saving_data.check_sub_folder(folder_name, 'figs')
            file_name = folder_name + '/' + file_name
            print(file_name)
            data_analysis_and_visulization.saving_data.check_fig_sub_folder(file_name)
            file_name = file_name + '/' + file_name_temp + '.png'
            print('file name  - ',file_name)
            pylab.savefig(file_name)
            #return file_name,folder_name
        
        def save_pd_dataframe(folder_name, file_name, dataframe):
            file_name_temp = file_name
            folder_name = data_analysis_and_visulization.saving_data.check_top_folder(folder_name)
            folder_name = data_analysis_and_visulization.saving_data.check_sub_folder(folder_name, 'figs')
            file_name = folder_name + '/' + file_name
            print(file_name)
            data_analysis_and_visulization.saving_data.check_fig_sub_folder(file_name)
            file_name = file_name + '/' + file_name_temp + '.df'
            print('file name  - ',file_name)
            dataframe.to_csv(path_or_buf = file_name)
        
        def save_classifier(folder_name,clf_type, clf):
            folder_name = data_analysis_and_visulization.saving_data.check_top_folder(folder_name)
            folder_name_temp = folder_name
            folder_name = data_analysis_and_visulization.saving_data.check_sub_folder(folder_name, 'classifier')
            file_name = folder_name + '/' + folder_name_temp + '_' + clf_type + '.p'
            print('file name  - ',file_name)
            print('folder name - ',folder_name)
            with open(file_name, 'wb') as f:
                pickle.dump(clf, f)
            return file_name,folder_name
        
        def save_clustering(folder_name,clf_type, clf):
            folder_name = data_analysis_and_visulization.saving_data.check_top_folder(folder_name)
            folder_name_temp = folder_name
            folder_name = data_analysis_and_visulization.saving_data.check_sub_folder(folder_name, 'clustering')
            file_name = folder_name + '/' + folder_name_temp + '_' + clf_type + '.p'
            print('file name  - ',file_name)
            print('folder name - ',folder_name)
            with open(file_name, 'wb') as f:
                pickle.dump(clf, f)
            return file_name,folder_name
        
        def save_decision_tree_png(folder_name, clf, data_original,data_set_column_droped,classification_column):
            folder_name = data_analysis_and_visulization.saving_data.check_top_folder(folder_name)
            folder_name_temp = folder_name
            folder_name = data_analysis_and_visulization.saving_data.check_sub_folder(folder_name, 'classifier')
            file_name = folder_name + '/' + folder_name_temp + '_decision_tree.png'
            print(file_name)
            print('saving png of decsion tree - ',file_name)
            classification_values = data_original[classification_column].unique()
            classification_values_converted = []
            
            names_of_features = data_set_column_droped.columns.values
            names_of_features_converted = []
            
            for i in range (len(classification_values)):
                classification_values_converted.append(str(classification_values[i]))
            
            for i in range (len(names_of_features)):
                names_of_features_converted.append(str(names_of_features[i]))
            
            dot_data = tree.export_graphviz(clf, out_file = None, class_names = classification_values_converted, feature_names = names_of_features_converted)
            graph = pydotplus.graph_from_dot_data(dot_data)
            graph.write_png(file_name)
            print('finished saving png of decsion tree - ',file_name)
    
    class loading_data():
        def read_data_in(file_location, header_state):
            print('reading data in')
            if header_state == False:
                #data_original = pd.read_csv('adult-t est.txt', header = None, delimiter =',\s+', skipinitialspace = True)
                data_original = pd.read_csv(file_location, header = None, sep = None, skipinitialspace = True)
            else:
                #data_original = pd.read_csv('adult-test.txt', delimiter =',\s+', skipinitialspace = True)
                data_original = pd.read_csv(file_location, sep = None, skipinitialspace = True)
            print('data read in')
            return data_original
        
        def load_object(file_location):
            pickle_in = open(file_location, 'rb')
            ax = pickle.load(pickle_in)
            return ax