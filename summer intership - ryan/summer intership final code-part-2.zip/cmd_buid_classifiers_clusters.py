#use this one to build classifiers and clusters object however to use new data on pre existing classifiers or clusters use load_classifiers_and_clusters.py

import matplotlib
matplotlib.use('TkAgg')
#import pandas as pd
from sklearn.model_selection import train_test_split
from code_restructored_gui_functions_seperate import data_analysis_and_visulization


class cmd_program():
    def pre_checks(self,file_location, header_state, columns_to_drop, classification_column, num_of_clusters,algarithm_choice):
        print('doing pre checks')
        if file_location == None:
            print('please give file location')
        else:
            if algarithm_choice == 'classification':
                if classification_column == None:
                    print('classification and no classification column')
                    print('unsupervised classification not currently implented')
                else:
                    print('classification and classification column')
                    self.classification_supervised(file_location, classification_column)
            else:
                if num_of_clusters == 0:
                    self.clustering_finding_k()
                else:
                    self.clustering(file_location, header_state, num_of_clusters)
        
    def classification_supervised(self,file_location, classification_column):
        print('starting classifying')
        clf_list = []
        X_train, X_test, Y_train, Y_test = train_test_split(self.data_set_column_droped,self.data_original[classification_column], test_size = 0.33)
        
        clf, Y_pred = self.classification_class.do_decsion_tree(X_train, X_test, Y_train, Y_test)
        file_name, folder_name = self.saving_data_class.save_classifier(file_location,'_decsion_tree',clf)
        #self.saving_data_class.save_decision_tree_png(file_location, clf, self.data_original,self.data_set_column_droped,classification_column)
        clf_list.append(clf)
        
        clf, Y_pred = self.classification_class.do_random_forest(X_train, X_test, Y_train, Y_test)
        file_name, folder_name = self.saving_data_class.save_classifier(file_location,'_random_forest', clf)
        clf_list.append(clf)
        
        clf, Y_pred = self.classification_class.do_support_vector_machine(X_train, X_test, Y_train, Y_test)
        file_name, folder_name = self.saving_data_class.save_classifier(file_location,'_support_vector_mahcine', clf)
        clf_list.append(clf)
        
        clf, Y_pred = self.classification_class.do_naive_bytes(X_train, X_test, Y_train, Y_test)
        file_name, folder_name = self.saving_data_class.save_classifier(file_location,'_naive_bytes', clf)
        clf_list.append(clf)
        
        clf, Y_pred = self.classification_class.do_nerual_net(X_train, X_test, Y_train, Y_test)
        file_name, folder_name = self.saving_data_class.save_classifier(file_location,'_nerual_net', clf)
        clf_list.append(clf)
        
        print('finished classifying')
        self.view_classified_dataset(clf_list)
    
    def view_classified_dataset(self,clf_list):
        continue_var = True
        while continue_var == True:
            print('0 - exit')
            print('1 - decsion tree')
            print('2 - random forest')
            print('3 - support vector machine')
            print('4 - naive bytes')
            print('5 - nerual net')
            user_input = int(input('chose which to view: '))
            if user_input == 0:
                continue_var = False
            elif (user_input != 1) and (user_input != 2) and (user_input != 3) and (user_input != 4) and (user_input != 5):
                print('invalid choice please enter one of the above choices')
            else:
                clf = clf_list[user_input - 1]
                clf_labels = clf.predict(self.data_set_column_droped)
                data_set = self.data_original.copy(deep = True)
                data_set['classification_column'] = clf_labels
                self.displaying_data_class.view_row(data_set)
    
    def clustering_finding_k(self):
        numerical_list, categorical_list = self.pre_processing_data_class.find_data_types(self.data_set_column_droped)
        if numerical_list != []:
            if categorical_list != []:
                self.clustering_class.find_k_kprotype(self.data_set_column_droped)
            else:
                self.clustering_class.find_k_kmeans(self.data_set_column_droped)
        else:
            self.clustering_class.find_k_kmode(self.data_set_column_droped)
    
    def clustering(self,file_location, header_state, num_of_clusters):
        numerical_list, categorical_list = self.pre_processing_data_class.find_data_types(self.data_set_column_droped)
        clf_type = None
        if numerical_list != []:
            if categorical_list != []:
                clf_labels_var = self.clustering_class.do_k_protype(num_of_clusters, self.data_set_column_droped, categorical_list)
                clf_type = 'k_protype'
            else:
                clf = self.clustering_class.do_k_means(num_of_clusters, self.data_set_column_droped.copy())
                clf_labels_var = clf.labels_
                clf_type = 'k_means'
        else:
            clf_labels_var = self.clustering_class.do_k_modes(num_of_clusters, self.data_set_column_droped)
            clf_type = 'k_modes'
        
        print('data original - ',self.data_original.shape, ' : clf labels var - ',clf_labels_var.shape)
        self.data_original_cluster_labels = self.clustering_class.attach_cluster_labels(self.data_original, clf_labels_var)
        self.data_set_column_droped_cluster_labels = self.clustering_class.attach_cluster_labels(self.data_set_column_droped.copy(deep=True), clf_labels_var)

        self.data_set_numerical_data_converted_cluster_labels = self.clustering_class.attach_cluster_labels(self.data_set_numerical_data_converted.copy(deep=True), clf_labels_var)

        self.data_set_pca = self.displaying_data_class.do_pca(self.data_set_numerical_data_converted)
        self.data_set_pca_group_cluster = self.clustering_class.attach_cluster_labels(self.data_set_pca, clf_labels_var)
        
        columns_to_use = self.displaying_data_class.get_columns_to_use()
        print(columns_to_use)
        self.displaying_data_class.plotting_multiple_plots(self.data_set_numerical_data_converted_cluster_labels,columns_to_use, file_location, header_state, '')

        columns_to_use = [[0,1],[0,1,2]]
        self.displaying_data_class.plotting_multiple_plots(self.data_set_pca_group_cluster,columns_to_use, file_location, header_state, 'pca')
        
        self.saving_data_class.save_clustering(file_location,clf_type,clf)
        
    def __init__(self,file_location, header_state, columns_to_drop, classification_column, num_of_clusters, algarithm_choice):
        self.data_analysis_and_visulization_class = data_analysis_and_visulization
        self.pre_processing_data_class = self.data_analysis_and_visulization_class.pre_processing_data
        self.clustering_class = self.data_analysis_and_visulization_class.clustering
        self.classification_class = self.data_analysis_and_visulization_class.classification
        self.displaying_data_class = self.data_analysis_and_visulization_class.displaying_data
        self.saving_data_class = self.data_analysis_and_visulization_class.saving_data
        self.loading_data_class = self.data_analysis_and_visulization_class.loading_data
        
        self.data_original = None
        self.data_original_cluster_labels = None
        
        self.data_set_column_droped = None
        self.data_set_column_droped_cluster_labels = None
        
        self.data_set_numerical_data_converted = None

        self.data_set_tsne = None
        self.data_set_tsne_group_cluster = None
        
        self.data_set_pca = None
        self.data_set_pca_group_cluster = None
        
        self.data_set_tsne = None
        self.data_set_tsne_group_cluster = None
        
        self.data_original = self.loading_data_class.read_data_in(file_location, header_state)
        self.data_original = self.data_original.dropna(axis=0, how='any')
        self.data_set_column_droped = self.pre_processing_data_class.drop_columns(self.data_original, columns_to_drop, classification_column, header_state)
        
        if algarithm_choice == 'clustering':
            self.data_set_numerical_data_converted = self.pre_processing_data_class.find_data_types_and_convert(self.data_set_column_droped)
                
        self.pre_checks(file_location, header_state, columns_to_drop, classification_column, num_of_clusters, algarithm_choice)